# Cairo Font Files

Download Cairo font from Google Fonts:
https://fonts.google.com/specimen/Cairo

Required files:
- Cairo-Regular.ttf
- Cairo-Bold.ttf
- Cairo-ExtraBold.ttf

Place them in this directory.
